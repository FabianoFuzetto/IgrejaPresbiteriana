import Pagina from "../templates/Pagina";
import imagemmenu from "../Imagens/imagemmenu.png"

export default function TelaMenu(props){
    return (
        <Pagina>

    
        <img className="shadow-lg bg-white rounded"  src={imagemmenu} alt="imagem"/>
   

        </Pagina>

    
    );
}


