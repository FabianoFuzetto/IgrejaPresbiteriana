import PessoaBD from "../Persistencia/PessoaBD.js";
export default class Pessoa {

    #cpf;
    #nome;
    #dataNasc;
    #genero;
    #endereco;
    #bairro;
    #cidade;
    #uf;
    #cep;
    #email;
    #celular;


    constructor(cpf, nome, dataNasc, genero, endereco, bairro, cidade, uf, cep, email, celular,) {
        this.#cpf = cpf;
        this.#nome = nome;
        this.#dataNasc = dataNasc;
        this.#genero = genero;
        this.#endereco = endereco;
        this.#bairro = bairro;
        this.#cidade = cidade;
        this.#uf = uf;
        this.#cep = cep;
        this.#email = email;
        this.#celular = celular;
    }

    get cpf() {
        return this.#cpf;
    }

    set cpf(novocpf) {
        this.#cpf = novocpf;
    }

    get nome() {
        return this.#nome;
    }

    set nome(novoNome) {
        if (novoNome != "")
            this.#nome = novoNome;
    }

    get dataNasc() {
        return this.#dataNasc;
    }

    set dataNasc(novaDataNasc) {
        if (novaDataNasc != "")
            this.#dataNasc = novaDataNasc;
    }

    get genero() {
        return this.#genero;
    }

    set genero(novoGenero) {
        if (novoGenero != "")
            this.#genero = novoGenero;
    }

    get endereco() {
        return this.#endereco;
    }

    set endereco(novoEnd) {
        this.#endereco = novoEnd;
    }

    get bairro() {
        return this.#bairro;
    }

    set bairro(novoBairro) {
        this.#bairro = novoBairro;
    }

    get cidade() {
        return this.#cidade;
    }

    set cidade(novaCidade) {
        this.#cidade = novaCidade
    }

    get uf() {
        return this.#uf;
    }

    set uf(novaUf) {
        this.#uf = novaUf;
    }

    get cep() {
        return this.#cep;
    }

    set cep(novoCep) {
        this.#cep = novoCep;
    }

    get email() {
        return this.#email;
    }

    set email(novoEmail) {
        this.#email = novoEmail;
    }


    get celular() {
        return this.#celular;
    }

    set celular(novoCel) {
        this.#celular = novoCel;
    }


    toJSON() {
        return {
            "cpf": this.#cpf,
            "nome": this.#nome,
            "dataNasc": this.#dataNasc,
            "genero": this.#genero,
            "endereco": this.#endereco,
            "bairro": this.#bairro,
            "cidade": this.#cidade,
            "uf": this.#uf,
            "cep": this.#cep,
            "email": this.#email,
            "celular": this.#celular,
        }
    }

    async gravar() {
        const pessoaBD = new PessoaBD();
        await pessoaBD.incluir(this);
    }

    async atualizar() {
        const pessoaBD = new PessoaBD();
        console.log(this)
        await pessoaBD.alterar(this);
    }

    async removerDoBanco() {
        const pessoaBD = new PessoaBD();
        await pessoaBD.excluir(this);
    }

    async consultar(termo) {
        const pessoaBD = new PessoaBD();
        const pessoa = await pessoaBD.consultar(termo);
        return pessoa;
    }

    async consultarCPF(cpf) {
        const pessoaBD = new PessoaBD();
        const pessoa = await pessoaBD.consultarCPF(cpf);
        return pessoa;
    }
}