import PatrimonioBD from "../Persistencia/PatrimonioBD.js";
export default class Patrimonio{

    #id; 
    #nomeDoPatrimonio;
    #dataPatrimonio;
    #ValorDoPatrimonio;
    #Condicao;
    #Descricao;
    #Codigo;
    
    constructor(id, nomeDoPatrimonio, dataPatrimonio, ValorDoPatrimonio, Condicao, Descricao, Codigo){
        if (id){
            this.#id = id;
        }
        this.#nomeDoPatrimonio = nomeDoPatrimonio;
        this.#dataPatrimonio = dataPatrimonio;
        this.#ValorDoPatrimonio = ValorDoPatrimonio;
        this.#Condicao = Condicao;
        this.#Descricao = Descricao;
        this.Codigo = Codigo;
        
    }

    get id(){
       return this.#id;
    }

    set id(novoid){
        this.#id = novoid;
    }

    get nomeDoPatrimonio(){
        return this.#nomeDoPatrimonio;
    }

    set nomeDoPatrimonio(novoNomeDoPatrimonio){
        if(novoNomeDoPatrimonio != "")
            this.#nomeDoPatrimonio = novoNomeDoPatrimonio;
    }

    get dataPatrimonio(){
        return this.#dataPatrimonio;
    }

    set dataPatrimonio(novoDataPatrimonio){
        this.#dataPatrimonio = novoDataPatrimonio;
    }

    get ValorDoPatrimonio(){
        return this.#ValorDoPatrimonio;
    }

    set ValorDoPatrimonio(novoValorDoPatrimonio){
        this.#ValorDoPatrimonio = novoValorDoPatrimonio;
    }
    get Condicao(){
        return this.#Condicao;
    }

    set Condicao(novaCondicao){
        this.#Condicao = novaCondicao;
    }

    get Descricao(){
        return this.#Descricao;
    }

    set Descricao(novoDescri){
        this.#Descricao = novoDescri;
    }

    get Codigo(){
        return this.#Codigo;
    }

    set Codigo(novoCodigo){
        this.#Codigo = novoCodigo;
    }


    toJSON(){
        return {
            "id"                    : this.#id,    
            "nomeDoPatrimonio"      : this.#nomeDoPatrimonio,
            "dataPatrimonio"        : this.#dataPatrimonio,
            "ValorDoPatrimonio"     : this.#ValorDoPatrimonio,
            "Condicao"              : this.#Condicao,
            "Descricao"             : this.#Descricao,
            "Codigo"                : this.#Codigo,
           
        }
    }

    async gravar(){
        const patrimonioBD = new PatrimonioBD();
        await patrimonioBD.incluir(this);
    }

    async atualizar(){
        const patrimonioBD = new PatrimonioBD();
        await patrimonioBD.alterar(this);
    }

    async removerDoBanco(){
        const patrimonioBD = new PatrimonioBD();
        await patrimonioBD.excluir(this);
    }

    async consultar(termo){
        const patrimonioBD = new PatrimonioBD();
        const patrimonio = await patrimonioBD.consultar(termo);
        return patrimonio;
    }

    async consultarID(id){
        const patrimonioBD = new PatrimonioBD();
        const patrimonio = await patrimonioBD.consultarID(id);
        return patrimonio;
    }
}