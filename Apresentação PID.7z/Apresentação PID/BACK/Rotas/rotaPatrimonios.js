import { Router } from "express";
import PatrimoniosCTRL from "../Controle/PatrimonioCtrl.js";

const rotaPatrimonios = new Router();
const patrimoniosCTRL = new PatrimoniosCTRL();

rotaPatrimonios.post('/', patrimoniosCTRL.gravar)
.put('/',patrimoniosCTRL.atualizar)
.delete('/',patrimoniosCTRL.excluir)
.get('/',patrimoniosCTRL.consultar)
.get('/:id', patrimoniosCTRL.consultarPeloID);

export default rotaPatrimonios;

