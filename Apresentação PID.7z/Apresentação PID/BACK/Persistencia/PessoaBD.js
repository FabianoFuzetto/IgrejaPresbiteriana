import Pessoas from '../Modelo/Pessoas.js';
import conectar from './Conexao.js';
export default class PessoasBD {

    async incluir(pessoa) {

        if (pessoa instanceof Pessoas) {
            const conexao = await conectar();
            const sql = "INSERT INTO pessoa(cpf,nome,dataNasc,genero,endereco,bairro,cidade,uf,cep,email,celular) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            const valores = [pessoa.cpf, pessoa.nome, pessoa.dataNasc, pessoa.genero, pessoa.endereco, pessoa.bairro, pessoa.cidade, pessoa.uf, pessoa.cep, pessoa.email, pessoa.celular];
            await conexao.query(sql, valores);
        }

    }

    async alterar(pessoa) {
        console.log(pessoa)
        if (pessoa instanceof Pessoas) {
            console.log('update')

            const conexao = await conectar();
            const sql = "UPDATE pessoa SET nome=?,dataNasc = ? ,genero = ?,endereco = ?,bairro = ?,cidade = ?,uf = ?,cep = ?, email = ?,celular = ? WHERE cpf=?";
            const valores = [pessoa.nome, pessoa.dataNasc, pessoa.genero, pessoa.endereco, pessoa.bairro, pessoa.cidade, pessoa.uf, pessoa.cep, pessoa.email, pessoa.celular, pessoa.cpf];
            console.log(valores)
            await conexao.query(sql, valores);
        }
    }

    async excluir(pessoa) {

        if (pessoa instanceof Pessoas) {
            const conexao = await conectar();
            const sql = "DELETE FROM pessoa WHERE cpf=?";
            const valores = [pessoa.cpf];
            await conexao.query(sql, valores);
        }
    }

    async consultar(termo) {
        const conexao = await conectar();
        const sql = "SELECT * FROM pessoa WHERE nome LIKE ?";
        const valores = ['%' + termo + '%']
        const [rows] = await conexao.query(sql, valores);
        const listaPessoas = [];
        for (const row of rows) {
            const pessoa = new Pessoas(row['cpf'], row['nome'], row['dataNasc'], row['genero'], row['endereco'], row['bairro'], row['cidade'], row['uf'], row['cep'], row['email'], row['celular']);
            listaPessoas.push(pessoa);
        }
        return listaPessoas;
    }

    async consultarCPF(cpf) {

        const conexao = await conectar();
        const sql = "SELECT * FROM pessoa WHERE cpf = ?";
        const valores = [cpf]
        const [rows] = await conexao.query(sql, valores);
        const listaPessoas = [];
        for (const row of rows) {
            const pessoa = new Pessoas(row['cpf'], row['nome'], row['dataNasc'], row['genero'], row['endereco'], row['bairro'], row['cidade'], row['uf'], row['cep'], row['email'], row['celular']);
            listaPessoas.push(pessoa);
        }
        return listaPessoas;
    }
}