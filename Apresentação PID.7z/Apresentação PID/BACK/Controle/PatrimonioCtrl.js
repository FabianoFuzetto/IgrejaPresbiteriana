import Patrimonios from '../Modelo/Patrimonios.js';

export default class PatrimonioCTRL {

    gravar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "POST" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const id = dados.id;
            const nomeDoPatrimonio = dados.nomeDoPatrimonio;
            const dataPatrimonio = dados.dataPatrimonio;
            const ValorDoPatrimonio = dados.ValorDoPatrimonio;
            const Condicao = dados.Condicao;
            const Descricao = dados.Descricao;
            const Codigo = dados.Codigo;
            
            if (nomeDoPatrimonio && dataPatrimonio && ValorDoPatrimonio && Condicao && Descricao && Codigo) {
                const patrimonios = new Patrimonios(0, nomeDoPatrimonio, dataPatrimonio, ValorDoPatrimonio, Condicao, Descricao, Codigo);

                patrimonios.gravar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Novo patrimônio salvo com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados de um patrimônio"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou patrimônio no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    atualizar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "PUT" && requisicao.is('application/json')) {
            const dados = requisicao.body;

            const id = dados.id;
            const nomeDoPatrimonio = dados.nomeDoPatrimonio;
            const dataPatrimonio = dados.dataPatrimonio;
            const ValorDoPatrimonio = dados.ValorDoPatrimonio;
            const Condicao = dados.Condicao;
            const Descricao = dados.Descricao;
            const Codigo = dados.Codigo;

            if (id && nomeDoPatrimonio && dataPatrimonio && ValorDoPatrimonio && Condicao && Descricao && Codigo) {
                const patrimonios = new Patrimonios(id, nomeDoPatrimonio, dataPatrimonio, ValorDoPatrimonio, Condicao, Descricao, Codigo);
                
                patrimonios.atualizar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Patrimônio atualizado com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados de um patrimônio"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou patrimõnio no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    excluir(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "DELETE" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const id = dados.id;

            if (id) {
                const patrimonios = new Patrimonios(id);

                patrimonios.removerDoBanco().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Patrimônio excluído com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe o id do patrimônio conforme documentação da API"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou patrimônio no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    consultar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "GET") {

            const patrimonios = new Patrimonios();

            patrimonios.consultar('').then((patrimonios) => {
                resposta.status(200).json(patrimonios);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }

    consultarPeloID(requisicao, resposta) {
        resposta.type("application/json");

        const id = requisicao.params['id'];

        if (requisicao.method === "GET") {

            const patrimonios = new Patrimonios();

            patrimonios.consultarID(id).then((bens) => {
                resposta.status(200).json(bens);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }

}