import CategoriaBD from "../Persistencia/CategoriaBD.js";
export default class Categoria{

    #idCategoria;
    #nomecategoria;
    

    
    constructor(idCategoria,  nomecategoria){
        if (idCategoria){
            this.#idCategoria = idCategoria;
        }
       
        this.#nomecategoria = nomecategoria;
    
    }

    get idCategoria(){
        return this.#idCategoria;
        
    }
    set idCategoria(novoidCategoria){
        this.#idCategoria = novoidCategoria;
    } 

    get nomecategoria(){
        return this.#nomecategoria; 
        
    }

    set nomecategoria(novoNomeCategoria){
        this.#nomecategoria = novoNomeCategoria;
    }

    

    toJSON(){
        return{
            "idCategoria"   : this.#idCategoria,
            "nomecategoria": this.#nomecategoria,
            




        }
    }


    async gravar(){
        const categoriaBD = new CategoriaBD();
        await categoriaBD.incluir(this);

    }


    async atualizar(){
        const categoriaBD = new CategoriaBD();
        await categoriaBD.alterar(this);

    }


    async removerDoBancoDados(){
        const categoriaBD = new CategoriaBD();
        await categoriaBD.excluir(this);

    }


    async consultarPorId(idCategoria){
        const categoriaBD = new CategoriaBD();
        const categorias = await categoriaBD.consultarPorId(idCategoria)
        return categorias;
    }


    async consultar(nomecategoria){
        const categoriaBD = new CategoriaBD();
        const categorias = await categoriaBD.consultar(nomecategoria)
        return categorias;

    }       
}
