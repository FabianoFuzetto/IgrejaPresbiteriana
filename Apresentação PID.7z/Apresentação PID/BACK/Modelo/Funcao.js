import FuncaoBD from "../Persistencia/FuncaoBD.js";
export default class Funcao {

    #idCargo;
    #funcaomembro;

    constructor(idCargo, funcaomembro) {
        if (idCargo) {
            this.#idCargo = idCargo;
        }
        //this.#idCargo = idCargo;
        this.#funcaomembro = funcaomembro;

    }

    get idCargo() {
        return this.#idCargo;

    }
    set idCargo(novoidCargo) {
        this.#idCargo = novoidCargo;
    }

    get funcaomembro() {
        return this.#funcaomembro;

    }

    set funcaomembro(novafuncaomembro) {
        this.#funcaomembro = novafuncaomembro;
    }
    toJSON() {
        return {
            "idCargo": this.#idCargo,
            "funcaomembro": this.#funcaomembro,
        }
    }

    async gravar() {
        const funcaoBD = new FuncaoBD();
        await funcaoBD.incluir(this);

    }

    async atualizar() {
        const funcaoBD = new FuncaoBD();
        await funcaoBD.alterar(this);

    }

    async removerDoBancoDados() {
        const funcaoBD = new FuncaoBD();
        await funcaoBD.excluir(this);

    }

    async consultarPorId(idCargo) {
        const funcaoBD = new FuncaoBD();
        const funcoes = await funcaoBD.consultarPorId(idCargo)
        return funcoes;
    }

    async consultar(funcaomembro) {
        const funcaoBD = new FuncaoBD();
        const funcoes = await funcaoBD.consultar(funcaomembro)
        return funcoes;
    }
}