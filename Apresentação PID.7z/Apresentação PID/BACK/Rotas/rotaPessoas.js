import { Router } from "express";
import PessoasCTRL from "../Controle/PessoaCtrl.js";

const rotaPessoas = new Router();
const pessoasCTRL = new PessoasCTRL();

rotaPessoas.post('/', pessoasCTRL.gravar)
.put('/',pessoasCTRL.atualizar)
.delete('/',pessoasCTRL.excluir)
.get('/',pessoasCTRL.consultar)
.get('/:cpf', pessoasCTRL.consultarPeloCPF);

export default rotaPessoas;