import Pessoas from '../Modelo/Pessoas.js';


export default class PessoaCTRL {

    gravar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "POST" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const cpf = dados.cpf;
            const nome = dados.nome;
            const dataNasc = dados.dataNasc;
            const genero = dados.genero;
            const endereco = dados.endereco;
            const bairro = dados.bairro;
            const cidade = dados.cidade;
            const uf = dados.uf;
            const cep = dados.cep;
            const email = dados.email;
            const celular = dados.celular;
            console.log(dados)
            if (cpf && nome && dataNasc && genero && endereco && bairro && cidade && uf && cep && email && celular  ) {
                const pessoas = new Pessoas(cpf, nome, dataNasc, genero, endereco, bairro, cidade, uf, cep,email, celular );
                pessoas.gravar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Membro gravado com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados de um membro"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou membro no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    atualizar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "PUT" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const cpf = dados.cpf;
            const nome = dados.nome;
            const dataNasc = dados.dataNasc;
            const genero = dados.genero;
            const endereco = dados.endereco;
            const bairro = dados.bairro;
            const cidade = dados.cidade;
            const uf = dados.uf;
            const cep = dados.cep;
            const email = dados.email;
            const celular = dados.celular;
            
            if (cpf && nome && dataNasc && genero && endereco && bairro && cidade && uf && cep && email  && celular) {
                const pessoas = new Pessoas(cpf, nome, dataNasc, genero, endereco, bairro, cidade, uf, cep, email, celular );

                pessoas.atualizar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Membro atualizado com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados de um membro"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou membro no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    excluir(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "DELETE" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const cpf = dados.cpf;

            if (cpf) {
                const pessoas = new Pessoas(cpf);

                pessoas.removerDoBanco().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Membro excluído com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe o cpf do membro conforme documentação da API"

                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou membro no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }

    consultar(requisicao, resposta) {
        resposta.type("application/json");

        if (requisicao.method === "GET") {

            const pessoas = new Pessoas();

            pessoas.consultar('').then((pessoas) => {
                resposta.status(200).json(pessoas);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }

    consultarPeloCPF(requisicao, resposta) {
        resposta.type("application/json");

        const cpf = requisicao.params['cpf'];

        if (requisicao.method === "GET") {

            const pessoas = new Pessoas();

            pessoas.consultarCPF(cpf).then((pessoas) => {
                resposta.status(200).json(pessoas);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }

}