import Funcao from '../Modelo/Funcao.js';

export default class FuncaoCTRL {

    gravar(requisicao, resposta) {
        resposta.type("application/json");
        
        if (requisicao.method === "POST" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCargo = dados.idCargo;
            const funcaomembro = dados.funcaomembro;
            if (funcaomembro) {
                const funcao = new Funcao(0, funcaomembro);
                funcao.gravar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Funcão gravada com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados, conforme documentação da API!"
                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou função no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }
    atualizar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "PUT" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCargo = dados.idCargo;
            const funcaomembro = dados.funcaomembro;
            if (idCargo && funcaomembro) {
                const funcao = new Funcao(idCargo, funcaomembro);
                funcao.atualizar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Funcão atualizada com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    });
                })
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados, conforme documentação da API!"
                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou cliente no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }
    excluir(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "DELETE" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCargo = dados.idCargo;
            if (idCargo) {
                const funcao = new Funcao(idCargo);
                funcao.removerDoBancoDados().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Funcão excluída com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    });
                })
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe o id do membro conforme documentação da API!"
                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou cliente no formato JSON não fornecido! Consulte a documentação da API"
            });
        }

    }
    consultar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "GET") {
            const funcao = new Funcao();
            funcao.consultar('').then((funcoes) => {
                resposta.status(200).json(funcoes);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }
    consultarPorId(requisicao, resposta) {
        resposta.type("application/json");

        const idCargo = requisicao.params['idCargo'];

        if (requisicao.method === "GET") {
            const funcao = new Funcao();

            funcao.consultarPorId(idCargo).then((funcoes) => {
                resposta.status(200).json(funcoes);

            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message

                })

            });



        }

        else {

            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }
}