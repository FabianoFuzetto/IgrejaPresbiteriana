import Patrimonio from '../Modelo/Patrimonios.js';
import conectar from './Conexao.js';
export default class PatrimoniosBD {

    async incluir(patrimonio) {

        if (patrimonio instanceof Patrimonio) {

            const conexao = await conectar();
            const sql = "INSERT INTO patrimonio(id,nomeDoPatrimonio,dataPatrimonio,ValorDoPatrimonio, Condicao,Descricao,Codigo) VALUES(?,?,?,?,?,?,?)";
            const valores = [patrimonio.id, patrimonio.nomeDoPatrimonio, patrimonio.dataPatrimonio, patrimonio.ValorDoPatrimonio, patrimonio.Condicao, patrimonio.Descricao, patrimonio.Codigo];
            await conexao.query(sql, valores);
        }
    }

    async alterar(patrimonio) {

        if (patrimonio instanceof Patrimonio) {
            const conexao = await conectar();
            const sql = "UPDATE patrimonio SET nomeDoPatrimonio = ?,dataPatrimonio = ?,ValorDoPatrimonio = ?,Condicao = ?,Descricao = ?,Codigo = ? WHERE id=?";
            const valores = [patrimonio.nomeDoPatrimonio, patrimonio.dataPatrimonio, patrimonio.ValorDoPatrimonio, patrimonio.Condicao, patrimonio.Descricao, patrimonio.Codigo, patrimonio.id];
            await conexao.query(sql, valores);
        }
    }
    async excluir(patrimonio) {

        if (patrimonio instanceof Patrimonio) {
            const conexao = await conectar();
            const sql = "DELETE FROM patrimonio WHERE id=?";
            const valores = [patrimonio.id];
            await conexao.query(sql, valores);
        }
    }

    async consultar(termo) {
        const conexao = await conectar();
        const sql = "SELECT * FROM patrimonio WHERE id LIKE ?";
        const valores = ['%' + termo + '%']
        const [rows] = await conexao.query(sql, valores);
        const listaPatrimonios = [];
        for (const row of rows) {
            const patrimonio = new Patrimonio(row['id'], row['nomeDoPatrimonio'], row['dataPatrimonio'], row['ValorDoPatrimonio'], row['Condicao'], row['Descricao'], row['Codigo']);
            listaPatrimonios.push(patrimonio);
        }
        return listaPatrimonios;
    }
    async consultarID(id) {

        const conexao = await conectar();
        const sql = "SELECT * FROM patrimonio WHERE id = ?";
        const valores = [id]
        const [rows] = await conexao.query(sql, valores);
        const listaPatrimonios = [];
        for (const row of rows) {
            const patrimonio = new Patrimonio(row['id'], row['nomeDoPatrimonio'], row['dataPatrimonio'], row['ValorDoPatrimonio'], row['Condicao'], row['Descricao'], row['Codigo']);
            listaPatrimonios.push(patrimonio);
        }
        return listaPatrimonios;
    }
}