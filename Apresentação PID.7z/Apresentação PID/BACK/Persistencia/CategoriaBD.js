import Categoria from '../Modelo/Categoria.js';
import conectar from './Conexao.js';

export default class CategoriaBD {

    async incluir(categoria) {

        if (categoria instanceof Categoria) {
            const conexao = await conectar();
            const sql = "INSERT INTO categoria(idCategoria,nomecategoria) VALUES (?,?)";
            const valores = [categoria.idCategoria, categoria.nomecategoria];
            await conexao.query(sql, valores);
        }

    }
    async alterar(categoria) {

        if (categoria instanceof Categoria) {
            const conexao = await conectar();
            const sql = "UPDATE categoria SET nomecategoria=? WHERE idCategoria =?";
            const valores = [categoria.nomecategoria, categoria.idCategoria];
            await conexao.query(sql, valores);
        }
    }

    async excluir(categoria) {

        if (categoria instanceof Categoria) {
            const conexao = await conectar();
            const sql = "DELETE FROM categoria WHERE idCategoria =?";
            const valores = [categoria.idCategoria];
            await conexao.query(sql, valores);
        }

    }

    async consultardata(nomecategoria) {
        const conexao = await conectar();
        const sql = "SELECT * FROM categoria WHERE nomecategoria = ?";
        const valores = ['%' + nomecategoria + '%']
        const [rows] = await conexao.query(sql, valores);
        const listaCategoria = [];
        for (const row of rows) {
            const categoria = new Categoria(row['idCategoria'], row['nomecategoria'])
            listaCategoria.push(categoria);
        }
        return listaCategoria;

    }

    async consultar(idCategoria) {
        const conexao = await conectar();
        const sql = "SELECT * FROM categoria WHERE idCategoria LIKE ?";
        const valores = ['%' + idCategoria + '%']
        const [rows] = await conexao.query(sql, valores);
        console.log("Resultados da consulta: ", rows);
        const listaCategoria = [];
        for (const row of rows) {
            const categoria = new Categoria(row['idCategoria'], row['nomecategoria'])
            listaCategoria.push(categoria);
        }
        return listaCategoria;
    }
}
