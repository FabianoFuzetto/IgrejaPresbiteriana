import {Router} from "express";
import CategoriaCTRL from "../Controle/CategoriaCtrl.js";

const rotaCategoria = new Router();
const categoriaCTRL = new CategoriaCTRL();

rotaCategoria.post('/', categoriaCTRL.gravar)
.put('/', categoriaCTRL.atualizar)
.delete('/', categoriaCTRL.excluir)
.get('/', categoriaCTRL.consultar)
.get('/:categoria', categoriaCTRL.consultarPorId);

export default rotaCategoria;