import Funcao from '../Modelo/Funcao.js';
import conectar from './Conexao.js';

export default class FuncaoBD {

    async incluir(funcao) {

        if (funcao instanceof Funcao) {

            const conexao = await conectar();
            const sql = "INSERT INTO funcao(idCargo,funcaomembro) VALUES (?,?)";
            const valores = [funcao.idCargo, funcao.funcaomembro];
            await conexao.query(sql, valores);
        }
    }
    async alterar(funcao) {

        if (funcao instanceof Funcao) {
            const conexao = await conectar();
            const sql = "UPDATE funcao SET funcaomembro=? WHERE idCargo =?";
            const valores = [funcao.funcaomembro, funcao.idCargo];
            await conexao.query(sql, valores);
        }
    }

    async excluir(funcao) {

        if (funcao instanceof Funcao) {
            const conexao = await conectar();
            const sql = "DELETE FROM funcao WHERE idCargo =?";
            const valores = [funcao.idCargo];
            await conexao.query(sql, valores);
        }

    }

    async consultardata(funcaomembro) {
        const conexao = await conectar();
        const sql = "SELECT * FROM funcao WHERE funcaomembro = ?";
        const valores = ['%' + funcaomembro + '%']
        const [rows] = await conexao.query(sql, valores);
        const listaFuncao = [];
        for (const row of rows) {
            const funcao = new Funcao(row['idCargo'], row['funcaomembro'])
            listaFuncao.push(funcao);
        }
        return listaFuncao;

    }

    async consultar(idCargo) {
        const conexao = await conectar();
        const sql = "SELECT * FROM funcao WHERE idCargo LIKE ?";
        const valores = ['%' + idCargo + '%']
        const [rows] = await conexao.query(sql, valores);
        console.log("Resultados da consulta: ", rows);
        const listaFuncao = [];
        for (const row of rows) {
            const funcao = new Funcao(row['idCargo'], row['funcaomembro'])
            listaFuncao.push(funcao);
        }
        return listaFuncao;
    }
}