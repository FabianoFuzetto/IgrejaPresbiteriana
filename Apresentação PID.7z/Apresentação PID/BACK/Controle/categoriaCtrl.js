import Categoria from '../Modelo/Categoria.js';

export default class CategoriaCTRL {

    gravar(requisicao, resposta) {
        resposta.type("application/json");
        
        if (requisicao.method === "POST" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCategoria = dados.idCategoria;
            const nomecategoria = dados.nomecategoria;
            if (nomecategoria) {
                const categoria = new Categoria(0, nomecategoria);
                categoria.gravar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Categoria gravada com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    })
                });
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados, conforme documentação da API!"
                })
            }

        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou categoria no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }
    atualizar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "PUT" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCategoria = dados.idCategoria;
            const nomecategoria = dados.nomecategoria;
            if (idCategoria && nomecategoria) {
                const categoria = new Categoria(idCategoria, nomecategoria);
                categoria.atualizar().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Categoria atualizada com sucesso!"
                    });

                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    });
                })
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe adequadamente todos os dados, conforme documentação da API!"
                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou cliente no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }
    excluir(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "DELETE" && requisicao.is('application/json')) {
            const dados = requisicao.body;
            const idCategoria = dados.idCategoria;
            if (idCategoria) {
                const categoria = new Categoria(idCategoria);
                categoria.removerDoBancoDados().then(() => {
                    resposta.status(200).json({
                        status: true,
                        mensagem: "Categoria excluída com sucesso!"
                    });
                }).catch((erro) => {
                    resposta.status(500).json({
                        status: false,
                        mensagem: erro.message
                    });
                })
            }
            else {
                resposta.status(400).json({
                    status: false,
                    mensagem: "Informe o id da categoria conforme documentação da API!"
                })
            }
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido ou cliente no formato JSON não fornecido! Consulte a documentação da API"
            });
        }
    }
    consultar(requisicao, resposta) {
        resposta.type("application/json");
        if (requisicao.method === "GET") {
            const categoria = new Categoria();
            categoria.consultar('').then((categorias) => {
                resposta.status(200).json(categorias);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }
    consultarPorId(requisicao, resposta) {
        resposta.type("application/json");
        const idCategoria = requisicao.params['idCategoria'];
        if (requisicao.method === "GET") {
            const categoria = new Categoria();
            categoria.consultarPorId(idCategoria).then((categorias) => {
                resposta.status(200).json(categorias);
            }).catch((erro) => {
                resposta.status(500).json({
                    status: false,
                    mensagem: erro.message
                })
            });
        }
        else {
            resposta.status(400).json({
                status: false,
                mensagem: "Método não permitido! Consulte a documentação da API"
            });
        }
    }
}