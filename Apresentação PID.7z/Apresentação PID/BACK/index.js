import express from 'express';
import cors from 'cors';

import rotaPatrimonio from './Rotas/rotaPatrimonios.js';
import rotaCategoria from './Rotas/rotaCategoria.js';
import rotaFuncao from './Rotas/rotaFuncao.js';
import rotaPessoas from './Rotas/rotaPessoas.js';

const app = express();

app.use(cors({origin:'*'}));

app.use(express.urlencoded({extend:false}));

app.use(express.json());

app.use('/patrimonios', rotaPatrimonio);
app.use('/categoria', rotaCategoria);
app.use('/funcao', rotaFuncao);
app.use('/pessoa', rotaPessoas);

app.listen(3100, 'localhost', ()=>{
    console.log("Backend ouvindo em http://localhost:3100");
})














